package fiuba.algo3.AlgoBay;

/**
 * Created by nico on 29/10/17.
 */
public interface Envio {
    double getCosto(double unPrecio);
}
